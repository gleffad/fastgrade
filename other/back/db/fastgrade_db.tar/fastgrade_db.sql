drop table professor;
drop table student;
drop table admin;
drop table ue;
drop table subject;
drop table exercise;
drop table enum_language;
drop table follow;
drop table grading;
drop table answer;
drop table teach;

create table professor(
	professor_id				smallint			primary key,
	firstname					varchar(40)			not null,
	lastname					varchar(40)			not null,
	mail						varchar(50)			not null,
	passwd						varchar(50)			not null,
	account_status				boolean				not null
);
create table student(
	student_id					smallint			primary key,
	firstname					varchar(40)			not null,
	lastname					varchar(40)			not null,
	mail						varchar(50)			not null,
	passwd						varchar(50)			not null,
	account_status				boolean				not null
);
create table admin(
	admin_id					smallint			primary key auto_increment,
	firstname					varchar(40)			not null,
	lastname					varchar(40)			not null,
	mail						varchar(50)			not null,
	passwd						varchar(50)			not null,
	account_status				boolean				not null
);
create table ue(
	ue_code						varchar(20)			primary key,
	promotion					smallint			not null
);
create table subject(
	ue_code						varchar(20)			references ue(ue_code)
								on update cascade
								on delete cascade,
	subject_number				smallint			not null,
	statement					varchar(8000)		not null,
	constraint					pk_subject			primary key(ue_code, subject_number)
);
create table enum_language(
	language_name				varchar(20)			primary key
);
create table exercise(
	ue_code						varchar(20)			references ue(ue_code)
								on update cascade
								on delete cascade,
	subject_number				smallint			references subject(subject_number)
								on update cascade
								on delete cascade,
	exercise_number				smallint			not null,
	language_name				varchar(20)			references enum_language(language_name)
								on update cascade
								on delete cascade,
	statement					varchar(8000)		not null,
	deadline_date				date				not null,
	attributed_points			float(2,1)			not null,
	answer						varchar(3000)		not null,
	constraint					pk_exercise			primary key(ue_code, subject_number, exercise_number)
);
create table follow(
	student_id					smallint			references student(student_id)
								on update cascade
								on delete cascade,
	ue_code						varchar(20)			references ue(ue_code)
								on update cascade
								on delete cascade,
	constraint					pk_follow			primary key(student_id, ue_code)
);
create table grading(
	professor_id				smallint			references professor(professor_id)
								on update cascade
								on delete cascade,
	student_id					smallint			references student(student_id)
								on update cascade
								on delete cascade,
	ue_code						varchar(20)			references ue(ue_code)
								on update cascade
								on delete cascade,
	subject_number				smallint			references subject(subject_number)
								on update cascade
								on delete cascade,
	compilation_result			varchar(5000),
	exec_result					varchar(5000),
	grade						float(2,1)			not null,
	grade_visualisation_right	boolean				not null,
	grade_visualisation_date	date				not null,
	constraint					pk_grading			primary key(professor_id, student_id, ue_code, subject_number)
);
create table answer(
	student_id					smallint			references student(student_id)
								on update cascade
								on delete cascade,
	ue_code						varchar(20)			references ue(ue_code)
								on update cascade
								on delete cascade,
	subject_number				smallint			references subject(subject_number)
								on update cascade
								on delete cascade,
	exercise_number				smallint			references exercise(exercise_number)
								on update cascade
								on delete cascade,
	student_answer				varchar(5000),
	constraint					pk_answer			primary key(student_id, ue_code, subject_number, exercise_number)
);
create table teach(
	professor_id				smallint			references professor(professor_id)
								on update cascade
								on delete cascade,
	ue_code						varchar(20)			references ue(ue_code)
								on update cascade
								on delete cascade,
	constraint					pk_teach			primary key(professor_id, ue_code)
);
